<?php
// ===== アプリケーション設定 =====

define('APP_NAME', 'ロボット教室 シフト管理');
define('APP_VERSION', '1.0.0');


// セッション設定（セキュリティ強化）
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.gc_maxlifetime', 3600); // 1時間

// ===== データベース接続設定 =====
// 変更前（Docker用）
define('DB_HOST', 'db');
define('DB_NAME', 'shift_db');
define('DB_USER', 'shift_user');
define('DB_PASS', 'shift_pass');
define('DB_CHARSET', 'utf8mb4');
define('BASE_URL', 'http://localhost:8080');

// ★ サブディレクトリデプロイ設定
// ドメイン直下なら '' 、/shift_app/ で動かすなら '/shift_app'
define('BASE_PATH', '/shift_app');
// 変更後（ロリポップ用）
// define('DB_HOST', 'mysql403.lolipop.jp');   // ← メモしたサーバー名
// define('DB_NAME', 'LAA1629440_shift');       // ← メモしたDB名
// define('DB_USER', 'LAA1629440');       // ← メモしたユーザー名
// define('DB_PASS', '575Seisei');
// define('BASE_URL', 'https://hotaru.holy.jp/shift_app');
// DB接続情報（ロイロサーバーの値に変更すること）
// define('DB_HOST', 'mysql403.phy.lolipop.lan');
// define('DB_NAME', 'LAA1629440-shift');       // ← ロイロサーバーのDB名に変更
// define('DB_USER', 'LAA1629440');     // ← ロイロサーバーのDBユーザーに変更
// define('DB_PASS', '575Seisei');     // ← ロイロサーバーのDBパスワードに変更
// define('DB_CHARSET', 'utf8mb4');
// セッション設定
define('SESSION_LIFETIME', 1800); // 30分

// ===== シフト申請設定 =====
define('DEADLINE_BUFFER_DAYS', 0); // 締切当日まで申請可能

// ===== タイムゾーン =====
date_default_timezone_set('Asia/Tokyo');
